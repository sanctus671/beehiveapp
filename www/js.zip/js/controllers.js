angular.module('app.controllers', [])

.controller('ChecklistCtrl', function($scope,ionicTimePicker,ionicDatePicker, MainService, $ionicLoading, $ionicPopup) {
    $scope.checklist = {
        siteLocation:null,
        operator:null,
        plantName:null,
        hub:null,
        date:null,
        weather:null,
        startTime:null,
        finishTime:null,
        comments:null,
        engineOil:null,
        engineOilLitres:null,
        radiator:null,
        transOil:null,
        brakeOil:null,
        hydraulicOil:null,
        grease:null,
        wheels:null,
        quickHitch:null,
        airTanks:null,
        chains:null,
        hoses:null,
        lights:null,
        fire:null,
        safety:null,
        gauges:null,
        windows:null,
        brake:null,
        tidy:null,
        wof:null,
        hazardAssessment:null,
        notifiable:null,
        ppe:null,
        firstAidKit:null,
        fireLocation:null,
        signage:null  
    };
    
    
    var timePickerObj1 = {
        callback: function (val) {      //Mandatory
          if (typeof (val) === 'undefined') {
            console.log('Time not selected');
          } else {
            var selectedTime = new Date(val * 1000);
            var ampm = selectedTime.getUTCHours() < 12 ? "am" : "pm";
            var min = selectedTime.getUTCMinutes() < 10 ? "0" + selectedTime.getUTCMinutes() : selectedTime.getUTCMinutes();
            $scope.checklist.startTime = selectedTime.getUTCHours() + ":" + min + " " + ampm;
          }
        },
        inputTime: 50400,   //Optional
        format: 12,         //Optional
        step: 15,           //Optional
        setLabel: 'Set Time'    //Optional
    }; 
    
    var timePickerObj2 = {
        callback: function (val) {      //Mandatory
          if (typeof (val) === 'undefined') {
            console.log('Time not selected');
          } else {
            var selectedTime = new Date(val * 1000);
            var ampm = selectedTime.getUTCHours() < 12 ? "am" : "pm";
            var min = selectedTime.getUTCMinutes() < 10 ? "0" + selectedTime.getUTCMinutes() : selectedTime.getUTCMinutes();
            $scope.checklist.finishTime = selectedTime.getUTCHours() + ":" + min + " " + ampm;
          }
        },
        inputTime: 50400,   //Optional
        format: 12,         //Optional
        step: 15,           //Optional
        setLabel: 'Set Time'    //Optional
    };     
    
    var datePickerObj = {
      callback: function (val) {  //Mandatory
        console.log('Return value from the datepicker popup is : ' + val, new Date(val));
        var date = new Date(val)
        $scope.checklist.date = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
      },
      inputDate: new Date(),      //Optional
      mondayFirst: true,          //Optional
      templateType: 'popup'       //Optional
    };

    $scope.openDatePicker = function(){
      ionicDatePicker.openDatePicker(datePickerObj);
    };    
    
    
    $scope.openTimePicker1 = function(){
        ionicTimePicker.openTimePicker(timePickerObj1);
    }
    $scope.openTimePicker2 = function(){
        ionicTimePicker.openTimePicker(timePickerObj2);
    } 
    
    $scope.submitChecklist = function(){
        $ionicLoading.show({
            template: 'Submitting checklist...'
        });        
        console.log($scope.checklist);
        MainService.submitChecklist($scope.checklist).then(function(){
            $ionicLoading.hide();
            //connected to internet
            $ionicPopup.alert({
            title: 'Success',
            template: "Checklist submitted!"
            });             
        },function(){
            $ionicLoading.hide();
            //not connected to internet
            $ionicPopup.alert({
            title: 'Error',
            template: "You are not currently connected to the internet. Your checklist has been queued to sync when you have an internet connection."
            });              
        })
    }
    
    
    
    
    
    
    
    
    
})

.controller('HistoryCtrl', function($scope, MainService, $ionicPopup) {

  $scope.checklists = MainService.getChecklists();
  $scope.doSync = function(){
        $ionicPopup.alert({
        title: 'Sync started',
        template: "Syncing will complete in the background."
        });       
      MainService.syncChecklists();
  }
})

.controller('HistoryDetailCtrl', function($scope, $stateParams, MainService) {
  $scope.checklist = MainService.getChecklist($stateParams.historyId);
  
});
